from setuptools import setup

setup(
    name = 'myvsearch',
    version = '1.0',
    description = 'The Head First Pyton Search Tools',
    author = 'Greed',
    author_email = 'kanzew@gmail.com',
    url = 'headfirstlabs.com',
    py_modules = ['myvsearch'],
)
